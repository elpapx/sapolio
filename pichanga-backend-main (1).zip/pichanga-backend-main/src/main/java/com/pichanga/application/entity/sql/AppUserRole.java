package com.pichanga.application.entity.sql;

public enum AppUserRole {
    USER,
    ADMIN
}
