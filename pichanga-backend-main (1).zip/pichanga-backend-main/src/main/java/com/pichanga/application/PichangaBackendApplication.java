package com.pichanga.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PichangaBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(PichangaBackendApplication.class, args);
    }

}
