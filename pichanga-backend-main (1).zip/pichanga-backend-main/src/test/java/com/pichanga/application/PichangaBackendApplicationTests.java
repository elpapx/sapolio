package com.pichanga.application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PichangaBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
